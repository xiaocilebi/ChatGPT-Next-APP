import { ReactNode } from 'react';

